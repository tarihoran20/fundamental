package soalNo2C;

import soalNo2B.Saya_No2C;

public class DataC {

	public static void main(String[] args) {
	
		Saya_No2C call = new Saya_No2C();
		call.main(args);
		

	}

}
