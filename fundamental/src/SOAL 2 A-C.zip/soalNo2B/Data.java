package soalNo2B;

public class Data {

	public static void main(String[] args) {
		
		Saya s = new Saya();
		s.tampil();
		
	}

}
